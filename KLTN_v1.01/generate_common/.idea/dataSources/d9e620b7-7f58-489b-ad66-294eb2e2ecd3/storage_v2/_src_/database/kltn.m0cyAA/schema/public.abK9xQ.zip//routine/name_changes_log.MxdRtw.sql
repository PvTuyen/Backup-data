create function name_changes_log() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.kids_name <> OLD.kids_name THEN
        INSERT INTO kids_audit(kids_id,kids_name,modified_on)
        VALUES(OLD.id + 1,OLD.kids_name,now());
    END IF;

    RETURN NEW;
END;
$$;

alter function name_changes_log() owner to admin;

