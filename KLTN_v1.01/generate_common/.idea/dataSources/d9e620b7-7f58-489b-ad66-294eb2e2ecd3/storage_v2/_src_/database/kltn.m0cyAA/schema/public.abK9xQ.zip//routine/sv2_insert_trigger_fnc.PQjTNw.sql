create function sv2_insert_trigger_fnc() returns trigger
    language plpgsql
as
$$
DECLARE
    res text[];
BEGIN
    res = array_append(res,new.column_1::text);
    res = array_append(res,new.column_2::text);
    res = array_append(res,new.column_3::text);
    res = array_append(res,new.column_4::text);
    res = array_append(res,new.column_5::text);
    INSERT INTO "snapshot"
    VALUES(NOW()::timestamp with time zone,res,'sv2','insert');
    RETURN NEW;
END;
$$;

alter function sv2_insert_trigger_fnc() owner to admin;

