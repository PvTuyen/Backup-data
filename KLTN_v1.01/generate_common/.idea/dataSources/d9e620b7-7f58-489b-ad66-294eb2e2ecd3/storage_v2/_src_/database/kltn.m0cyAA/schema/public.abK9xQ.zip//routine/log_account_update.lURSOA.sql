create procedure log_account_update()
    language plpgsql
as
$$
begin
    -- subtracting the amount from the sender's account

end;
$$;

alter procedure log_account_update() owner to admin;

